import "./styles.css";
import Bmi from "./Components/BMI_calc";
export default function App() {
  return (
    <div className="App">
      <Bmi />
    </div>
  );
}
